
import java.util.Scanner;


/**
 * @author Roberto Valdez Vazquez 18550731
 */
public class Principal {

    
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
        System.out.println("---Practica 1---");
        System.out.println("Introduce un numero del 1 al 12");
      int iNumMes = input.nextInt();
      input.nextLine();
      String sMes = Mes(iNumMes);
        System.out.println(sMes);
        
        System.out.println("---Practica 2---");
        System.out.println("Ingresa tu calificacion en letra");
        String Letra = input.nextLine();
        int iNum = Califa(Letra);
        System.out.println("Tu calificacion es: " + iNum);
        
        System.out.println("---Practica 3---");
        System.out.println("Ingresa tu calificacion en numero");
        int iNumCalifa = input.nextInt();
              input.nextLine();
        String sNumCalifa =NumCalifa(iNumCalifa);
        System.out.println("Tu calificacion es: " + sNumCalifa);
        
    }
    public static String  Mes (int iMes) {
     String sNombre = "";   
    switch (iMes) {
            case 1:
            sNombre = "Enero";
            break;
            case 2:
            sNombre = "Febrero";
            break;
            case 3:
            sNombre = "Marzo";
            break;
            case 4:
            sNombre = "Abril";
            break;
            case 5:
            sNombre = "Mayo";
            break;
            case 6:
            sNombre = "Junio";
            break;
            case 7:
           sNombre = "Julio";
            break;
            case 8:
            sNombre = "Agosto";
            break;
            case 9:
            sNombre = "Septiembre";
            break;
            case 10:
           sNombre = "Octubre";
            break;
            case 11:
            sNombre = "Noviembre";
            break;
            case 12:
            sNombre = "Diciembre";
            break;
            default:
            sNombre = "Fuera de Rango";
           
            
    }    
    return sNombre;
    }
    public static int Califa(String sLetra){
    int iNum = 0;
    switch (sLetra){
        case "A":
            iNum = 100;
            break;
            case "B":
            iNum = 90;
            break;
            case "C":
            iNum = 80;
            break;
            case "D":
            iNum = 70;
            break;
            case "F":
            iNum = 0;
            break;
            default:
                System.out.println("Letra fuera de rango");
    }
     return iNum;       
    }    
    public static String NumCalifa(int iCalifa){
    String sCalifa = "";
    switch (iCalifa){
            case 100:
            sCalifa = "A";
            break;
            case 90:
            sCalifa = "B";
            break;
            case 80:
            sCalifa = "C";
            break;
            case 70:
            sCalifa = "D";
            break;
            case 60:
            sCalifa = "F";
            break;
            case 50:
            sCalifa = "F";
            break;
            case 40:
            sCalifa = "F";
            break;
            case 30:
            sCalifa = "F";
            break;
            case 20:
            sCalifa = "F";
            break;
            case 10:
            sCalifa = "F";
            break;
            case 0:
            sCalifa = "F";
            break;
            default:
                System.out.println("Numero fuera de rango");
                break;
    }
    return sCalifa;
    }    
    //public static int Dato (String sMensaje, int Edad){
      //  Scanner input = new Scanner(System.in);
       
    }
    


          
    

     
    
    
   

