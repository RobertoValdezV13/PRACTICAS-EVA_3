/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author temporal2
 */
public class RobClase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //LLAMADA DE FUNCION
       RobClase mObjeto = new RobClase();
        mObjeto.imprimemensaje("Roberto");
    Math.random();
    
    }
         void imprimemensaje (String mensaje){
       System.out.println("Hola " + mensaje); 
       }
    //PARADIGMAS DE PROGRAMACION
    //PROGRAMACION ESTRUCTURADA
    //ETC ETC ETC
    //nivel de acesso valor de retorno nombre de la funcion(argumentos) 
    //cuerpo de la funcion
    //op
    //publico privado protegido 
    //funciones regresan valores
    //procedimientos no regresan valores
   //void imprimemensaje (String mensaje){
     //  System.out.println("Hola " +mensaje);     
       
    }
